import { IMenu } from "../models";

export const menus: IMenu[] = [
    {name:"Поиск звонков", ion: "search-outline", url:"/"},
    {name:"Речевая аналитика", ion: "analytics-outline",url:"/charts"},
    {name:"Текстовый поиск", ion: "search-outline", url:"/textsearch"},
    {name:"Отправка файла", ion: "send-outline", url:"/sendfile"},
    {name:"Редактор Тэгов", ion: "pricetags-outline", url:"/tags"},
]